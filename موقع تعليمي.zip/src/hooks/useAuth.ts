import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { User, ROUTE_PATHS } from '@/lib/index';

interface AuthActions {
  login: (email: string, password: string) => Promise<boolean>;
  register: (name: string, email: string, password: string) => Promise<boolean>;
  logout: () => void;
  enrollInCourse: (courseId: string) => void;
  completeLesson: (lessonId: string) => void;
}

interface UseAuthReturn {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: AuthActions['login'];
  register: AuthActions['register'];
  logout: AuthActions['logout'];
  enrollInCourse: AuthActions['enrollInCourse'];
  completeLesson: AuthActions['completeLesson'];
}

const AUTH_STORAGE_KEY = 'edu_platform_user';

export const useAuth = (): UseAuthReturn => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const navigate = useNavigate();

  useEffect(() => {
    const checkAuth = () => {
      try {
        const storedUser = localStorage.getItem(AUTH_STORAGE_KEY);
        if (storedUser) {
          setUser(JSON.parse(storedUser));
        }
      } catch (error) {
        console.error('Error parsing stored user:', error);
        localStorage.removeItem(AUTH_STORAGE_KEY);
      } finally {
        setIsLoading(false);
      }
    };

    checkAuth();
  }, []);

  const login = useCallback(async (email: string, _password: string): Promise<boolean> => {
    setIsLoading(true);
    // Mock API delay
    await new Promise((resolve) => setTimeout(resolve, 800));

    const mockUser: User = {
      id: 'user_1',
      name: 'أحمد محمد',
      email: email,
      avatar: 'https://images.unsplash.com/photo-1633332755192-727a05c4013d?w=100&h=100&fit=crop',
      role: 'student',
      enrolledCourses: ['course_1', 'course_3'],
      completedLessons: ['lesson_101'],
      createdAt: new Date().toISOString(),
    };

    localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(mockUser));
    setUser(mockUser);
    setIsLoading(false);
    navigate(ROUTE_PATHS.DASHBOARD);
    return true;
  }, [navigate]);

  const register = useCallback(async (name: string, email: string, _password: string): Promise<boolean> => {
    setIsLoading(true);
    await new Promise((resolve) => setTimeout(resolve, 1000));

    const newUser: User = {
      id: Math.random().toString(36).substr(2, 9),
      name,
      email,
      role: 'student',
      enrolledCourses: [],
      completedLessons: [],
      createdAt: new Date().toISOString(),
    };

    localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(newUser));
    setUser(newUser);
    setIsLoading(false);
    navigate(ROUTE_PATHS.DASHBOARD);
    return true;
  }, [navigate]);

  const logout = useCallback(() => {
    localStorage.removeItem(AUTH_STORAGE_KEY);
    setUser(null);
    navigate(ROUTE_PATHS.HOME);
  }, [navigate]);

  const enrollInCourse = useCallback((courseId: string) => {
    if (!user) return;

    const updatedUser: User = {
      ...user,
      enrolledCourses: Array.from(new Set([...user.enrolledCourses, courseId])),
    };

    setUser(updatedUser);
    localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(updatedUser));
  }, [user]);

  const completeLesson = useCallback((lessonId: string) => {
    if (!user) return;

    const updatedUser: User = {
      ...user,
      completedLessons: Array.from(new Set([...user.completedLessons, lessonId])),
    };

    setUser(updatedUser);
    localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(updatedUser));
  }, [user]);

  return {
    user,
    isAuthenticated: !!user,
    isLoading,
    login,
    register,
    logout,
    enrollInCourse,
    completeLesson,
  };
};
