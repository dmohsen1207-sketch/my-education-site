import { Course, Article, Instructor } from "@/lib/index";
import { IMAGES } from "@/assets/images";

export const instructors: Instructor[] = [
  {
    id: "inst-1",
    name: "أحمد المنصوري",
    role: "خبير مونتاج ومؤثرات بصرية",
    bio: "متخصص في صناعة المحتوى المرئي بخبرة تزيد عن 10 سنوات في برامج Adobe و DaVinci Resolve.",
    avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?q=80&w=200&h=200&fit=crop",
    coursesCount: 5,
    studentsCount: 12500,
    socialLinks: {
      twitter: "https://twitter.com",
      youtube: "https://youtube.com",
      linkedin: "https://linkedin.com"
    }
  },
  {
    id: "inst-2",
    name: "سارة خالد",
    role: "مصممة جرافيك وواجهات مستخدم",
    bio: "شغوفة بتحويل الأفكار إلى تصاميم بصرية مبهرة. عملت مع كبرى الشركات في المنطقة العربية.",
    avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?q=80&w=200&h=200&fit=crop",
    coursesCount: 4,
    studentsCount: 8400,
    socialLinks: {
      twitter: "https://twitter.com",
      linkedin: "https://linkedin.com"
    }
  },
  {
    id: "inst-3",
    name: "د. ياسين كريم",
    role: "متخصص في الذكاء الاصطناعي",
    bio: "باحث ومطور في مجال الذكاء الاصطناعي التوليدي، يسعى لتمكين الشباب العربي من أدوات المستقبل.",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=200&h=200&fit=crop",
    coursesCount: 3,
    studentsCount: 5200
  }
];

export const courses: Course[] = [
  {
    id: "course-1",
    title: "احتراف المونتاج ببرنامج Adobe Premiere Pro",
    description: "تعلم فن المونتاج من الصفر حتى الاحتراف، من ترتيب اللقطات إلى تصحيح الألوان.",
    longDescription: "هذه الدورة تأخذك في رحلة شاملة لتعلم أقوى برنامج مونتاج في العالم. ستتعلم كيفية بناء القصة، قص اللقطات باحترافية، إضافة الانتقالات، العمل على الصوت، وتصدير الفيديوهات بأفضل جودة لمنصات التواصل الاجتماعي.",
    category: "editing",
    level: "beginner",
    price: 49,
    image: IMAGES.VIDEO_EDITING_1,
    instructorId: "inst-1",
    duration: "12 ساعة",
    rating: 4.8,
    studentsCount: 3400,
    requirements: [
      "جهاز كمبيوتر بمواصفات متوسطة",
      "تثبيت برنامج Adobe Premiere Pro",
      "شغف بتعلم صناعة الفيديو"
    ],
    whatYouWillLearn: [
      "واجهة البرنامج وأدوات التعديل الأساسية",
      "تقنيات القص والترتيب المتقدمة",
      "تصحيح الألوان (Color Correction)",
      "إضافة النصوص والرسومات المتحركة"
    ],
    tools: ["Premiere Pro", "Adobe Media Encoder"],
    lessons: [
      { id: "l1", title: "مقدمة عن واجهة البرنامج", duration: "10:00", videoUrl: "#", isFree: true, order: 1 },
      { id: "l2", title: "استيراد وتنظيم الملفات", duration: "15:30", videoUrl: "#", isFree: false, order: 2 },
      { id: "l3", title: "أدوات القص الأساسية", duration: "20:00", videoUrl: "#", isFree: false, order: 3 }
    ]
  },
  {
    id: "course-2",
    title: "أساسيات التصميم الجرافيكي باستخدام Photoshop",
    description: "أتقن أقوى أداة للتصميم في العالم وابدأ مسيرتك المهنية كمصمم محترف.",
    longDescription: "ستتعلم في هذه الدورة كيفية التعامل مع الطبقات، الأقنعة، وأدوات التحديد المتقدمة. سنقوم بتنفيذ مشاريع حقيقية تشمل تصاميم السوشيال ميديا وتعديل الصور الشخصية.",
    category: "design",
    level: "beginner",
    price: "free",
    image: IMAGES.DESIGN_WORKSPACE_1,
    instructorId: "inst-2",
    duration: "8 ساعات",
    rating: 4.9,
    studentsCount: 12000,
    requirements: [
      "لا توجد متطلبات سابقة",
      "تثبيت برنامج Adobe Photoshop"
    ],
    whatYouWillLearn: [
      "فهم نظام الطبقات (Layers)",
      "دمج الصور بطريقة واقعية",
      "تصميم البوسترات وإعلانات السوشيال ميديا",
      "تقنيات معالجة الصور (Retouching)"
    ],
    tools: ["Photoshop"],
    lessons: [
      { id: "l4", title: "ما هو الفوتوشوب؟", duration: "05:00", videoUrl: "#", isFree: true, order: 1 },
      { id: "l5", title: "التعامل مع الطبقات", duration: "25:00", videoUrl: "#", isFree: true, order: 2 }
    ]
  },
  {
    id: "course-3",
    title: "الذكاء الاصطناعي للمبدعين: ChatGPT و Midjourney",
    description: "سخر قوة الذكاء الاصطناعي لزيادة إنتاجيتك في التصميم وكتابة المحتوى.",
    longDescription: "اكتشف كيف يمكنك استخدام ChatGPT لكتابة السيناريوهات وMidjourney لتوليد صور خيالية. سنتعلم كيفية كتابة الأوامر (Prompts) الفعالة للحصول على نتائج مذهلة.",
    category: "ai",
    level: "intermediate",
    price: 35,
    image: IMAGES.AI_TECHNOLOGY_1,
    instructorId: "inst-3",
    duration: "6 ساعات",
    rating: 4.7,
    studentsCount: 2100,
    requirements: [
      "معرفة أساسية باستخدام الحاسوب",
      "حساب على Discord لاستخدام Midjourney"
    ],
    whatYouWillLearn: [
      "هندسة الأوامر (Prompt Engineering)",
      "توليد الصور الاحترافية بالذكاء الاصطناعي",
      "أتمتة المهام المتكررة باستخدام ChatGPT",
      "صناعة محتوى كامل باستخدام الأدوات الذكية"
    ],
    tools: ["ChatGPT", "Midjourney", "Leonardo.ai"],
    lessons: [
      { id: "l6", title: "مستقبل الإبداع مع AI", duration: "12:00", videoUrl: "#", isFree: true, order: 1 },
      { id: "l7", title: "أسرار ChatGPT في صناعة المحتوى", duration: "30:00", videoUrl: "#", isFree: false, order: 2 }
    ]
  },
  {
    id: "course-4",
    title: "المؤثرات البصرية ببرنامج After Effects",
    description: "أضف لمسة سحرية لفيديوهاتك وتعلم صناعة الموشن جرافيك والمؤثرات.",
    category: "editing",
    level: "advanced",
    price: 79,
    image: IMAGES.VIDEO_EDITING_2,
    instructorId: "inst-1",
    duration: "15 ساعة",
    rating: 4.6,
    studentsCount: 1500,
    requirements: ["معرفة ببرنامج بريمير", "جهاز كمبيوتر قوي"],
    whatYouWillLearn: ["التحريك الأساسي والمتقدم", "نظام الكاميرات ثلاثي الأبعاد", "استخدام المكونات الإضافية (Plugins)"],
    tools: ["After Effects"],
    lessons: []
  },
  {
    id: "course-5",
    title: "تصميم الشعارات والهوية البصرية بـ Illustrator",
    description: "تعلم كيفية بناء علامات تجارية خالدة باستخدام الرسوم المتجهة (Vector).",
    category: "design",
    level: "intermediate",
    price: 55,
    image: IMAGES.DESIGN_WORKSPACE_2,
    instructorId: "inst-2",
    duration: "10 ساعات",
    rating: 4.8,
    studentsCount: 4200,
    requirements: ["معرفة بأساسيات التصميم"],
    whatYouWillLearn: ["التعامل مع أداة البن تول", "سيكولوجية الألوان في الشعارات", "بناء ملف الهوية البصرية كاملاً"],
    tools: ["Illustrator"],
    lessons: []
  },
  {
    id: "course-6",
    title: "توليد الفيديو والأتمتة بالذكاء الاصطناعي",
    description: "تعلم كيف تنشئ فيديوهات كاملة دون الحاجة للكاميرا أو الميكروفون.",
    category: "ai",
    level: "advanced",
    price: 65,
    image: IMAGES.AI_TECHNOLOGY_2,
    instructorId: "inst-3",
    duration: "7 ساعات",
    rating: 4.5,
    studentsCount: 1100,
    requirements: ["إتقان أدوات AI الأساسية"],
    whatYouWillLearn: ["استخدام HeyGen و Runway", "أتمتة قنوات اليوتيوب", "تحويل النص إلى فيديو واقعي"],
    tools: ["Runway Gen-2", "Pika Labs", "HeyGen"],
    lessons: []
  }
];

export const articles: Article[] = [
  {
    id: "art-1",
    title: "أفضل 5 أدوات ذكاء اصطناعي للمصممين في 2026",
    excerpt: "تعرف على الأدوات التي ستغير طريقة عملك وتوفر عليك ساعات من الجهد اليدوي.",
    content: "مع التطور المتسارع في عام 2026، أصبح الذكاء الاصطناعي جزءاً لا يتجزأ من عمل أي مصمم...",
    author: "د. ياسين كريم",
    date: "2026-01-20",
    image: IMAGES.AI_TECHNOLOGY_1,
    category: "نصائح تقنية",
    readTime: "5 دقائق",
    tags: ["AI", "Design", "Future"]
  },
  {
    id: "art-2",
    title: "كيف تبدأ مسيرتك كفرد في المونتاج الحر؟",
    excerpt: "خطوات عملية للوصول لأول عميل لك وبناء معرض أعمال (Portfolio) احترافي.",
    content: "العمل الحر في مجال المونتاج يتطلب مهارات تتجاوز مجرد معرفة البرامج...",
    author: "أحمد المنصوري",
    date: "2026-01-25",
    image: IMAGES.VIDEO_EDITING_2,
    category: "العمل الحر",
    readTime: "7 دقائق",
    tags: ["Freelancing", "Editing", "Career"]
  },
  {
    id: "art-3",
    title: "أسرار تناسق الألوان في التصميم الجرافيكي",
    excerpt: "دليل شامل لاختيار لوحات ألوان جذابة تعبر عن هوية علامتك التجارية.",
    content: "الألوان ليست مجرد زينة، بل هي لغة تخاطب اللاوعي لدى المشاهد...",
    author: "سارة خالد",
    date: "2026-01-28",
    image: IMAGES.DESIGN_WORKSPACE_2,
    category: "أساسيات التصميم",
    readTime: "6 دقائق",
    tags: ["Colors", "Theory", "Branding"]
  }
];