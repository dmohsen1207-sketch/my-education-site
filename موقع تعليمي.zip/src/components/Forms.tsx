import React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { motion } from 'framer-motion';
import { Mail, Lock, User as UserIcon, Send, Loader2, MessageSquare, Tag } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { useToast } from '@/components/ui/use-toast';

const loginSchema = z.object({
  email: z.string().email('يرجى إدخال بريد إلكتروني صالح'),
  password: z.string().min(6, 'كلمة المرور يجب أن تكون 6 أحرف على الأقل'),
});

const registerSchema = z.object({
  name: z.string().min(3, 'الاسم يجب أن يكون 3 أحرف على الأقل'),
  email: z.string().email('يرجى إدخال بريد إلكتروني صالح'),
  password: z.string().min(6, 'كلمة المرور يجب أن تكون 6 أحرف على الأقل'),
});

const contactSchema = z.object({
  name: z.string().min(3, 'يرجى إدخال اسمك الكامل'),
  email: z.string().email('يرجى إدخال بريد إلكتروني صالح'),
  subject: z.string().min(5, 'يرجى تحديد موضوع الرسالة'),
  message: z.string().min(10, 'يرجى كتابة رسالة لا تقل عن 10 أحرف'),
});

export function LoginForm() {
  const { login, isLoading } = useAuth();
  const { toast } = useToast();

  const form = useForm<z.infer<typeof loginSchema>>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      email: '',
      password: '',
    },
  });

  async function onSubmit(values: z.infer<typeof loginSchema>) {
    try {
      const success = await login(values.email, values.password);
      if (success) {
        toast({
          title: 'تم تسجيل الدخول بنجاح',
          description: 'مرحباً بك مرة أخرى في منصتنا التعليمية.',
        });
      }
    } catch (error) {
      toast({
        variant: 'destructive',
        title: 'فشل تسجيل الدخول',
        description: 'يرجى التحقق من البيانات والمحاولة مرة أخرى.',
      });
    }
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <FormField
          control={form.control}
          name="email"
          render={({ field }) => (
            <FormItem>
              <FormLabel>البريد الإلكتروني</FormLabel>
              <FormControl>
                <div className="relative">
                  <Mail className="absolute right-3 top-3 h-5 w-5 text-muted-foreground" />
                  <Input placeholder="example@domain.com" className="pr-10" {...field} />
                </div>
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="password"
          render={({ field }) => (
            <FormItem>
              <FormLabel>كلمة المرور</FormLabel>
              <FormControl>
                <div className="relative">
                  <Lock className="absolute right-3 top-3 h-5 w-5 text-muted-foreground" />
                  <Input type="password" placeholder="••••••••" className="pr-10" {...field} />
                </div>
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <Button type="submit" className="w-full font-bold h-12" disabled={isLoading}>
          {isLoading ? (
            <Loader2 className="h-5 w-5 animate-spin ml-2" />
          ) : (
            'تسجيل الدخول'
          )}
        </Button>
      </form>
    </Form>
  );
}

export function RegisterForm() {
  const { register, isLoading } = useAuth();
  const { toast } = useToast();

  const form = useForm<z.infer<typeof registerSchema>>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      name: '',
      email: '',
      password: '',
    },
  });

  async function onSubmit(values: z.infer<typeof registerSchema>) {
    try {
      const success = await register(values.name, values.email, values.password);
      if (success) {
        toast({
          title: 'تم إنشاء الحساب بنجاح',
          description: 'أهلاً بك في رحلتك التعليمية الجديدة.',
        });
      }
    } catch (error) {
      toast({
        variant: 'destructive',
        title: 'فشل إنشاء الحساب',
        description: 'حدث خطأ أثناء التسجيل، يرجى المحاولة لاحقاً.',
      });
    }
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <FormField
          control={form.control}
          name="name"
          render={({ field }) => (
            <FormItem>
              <FormLabel>الاسم الكامل</FormLabel>
              <FormControl>
                <div className="relative">
                  <UserIcon className="absolute right-3 top-3 h-5 w-5 text-muted-foreground" />
                  <Input placeholder="أدخل اسمك الكامل" className="pr-10" {...field} />
                </div>
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="email"
          render={({ field }) => (
            <FormItem>
              <FormLabel>البريد الإلكتروني</FormLabel>
              <FormControl>
                <div className="relative">
                  <Mail className="absolute right-3 top-3 h-5 w-5 text-muted-foreground" />
                  <Input placeholder="example@domain.com" className="pr-10" {...field} />
                </div>
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="password"
          render={({ field }) => (
            <FormItem>
              <FormLabel>كلمة المرور</FormLabel>
              <FormControl>
                <div className="relative">
                  <Lock className="absolute right-3 top-3 h-5 w-5 text-muted-foreground" />
                  <Input type="password" placeholder="••••••••" className="pr-10" {...field} />
                </div>
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <Button type="submit" className="w-full font-bold h-12" disabled={isLoading}>
          {isLoading ? (
            <Loader2 className="h-5 w-5 animate-spin ml-2" />
          ) : (
            'إنشاء حساب جديد'
          )}
        </Button>
      </form>
    </Form>
  );
}

export function ContactForm() {
  const { toast } = useToast();
  const [isSending, setIsSending] = React.useState(false);

  const form = useForm<z.infer<typeof contactSchema>>({
    resolver: zodResolver(contactSchema),
    defaultValues: {
      name: '',
      email: '',
      subject: '',
      message: '',
    },
  });

  async function onSubmit(values: z.infer<typeof contactSchema>) {
    setIsSending(true);
    // Mock API simulation
    await new Promise((resolve) => setTimeout(resolve, 1500));
    console.log('Contact message submitted:', values);
    setIsSending(false);
    
    toast({
      title: 'تم إرسال رسالتك',
      description: 'شكراً لتواصلك معنا، سنرد عليك في أقرب وقت ممكن.',
    });
    
    form.reset();
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          <FormField
            control={form.control}
            name="name"
            render={({ field }) => (
              <FormItem>
                <FormLabel>الاسم</FormLabel>
                <FormControl>
                  <div className="relative">
                    <UserIcon className="absolute right-3 top-3 h-5 w-5 text-muted-foreground" />
                    <Input placeholder="اسمك الكريم" className="pr-10" {...field} />
                  </div>
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="email"
            render={({ field }) => (
              <FormItem>
                <FormLabel>البريد الإلكتروني</FormLabel>
                <FormControl>
                  <div className="relative">
                    <Mail className="absolute right-3 top-3 h-5 w-5 text-muted-foreground" />
                    <Input placeholder="example@domain.com" className="pr-10" {...field} />
                  </div>
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>
        <FormField
          control={form.control}
          name="subject"
          render={({ field }) => (
            <FormItem>
              <FormLabel>الموضوع</FormLabel>
              <FormControl>
                <div className="relative">
                  <Tag className="absolute right-3 top-3 h-5 w-5 text-muted-foreground" />
                  <Input placeholder="بخصوص ماذا تتواصل معنا؟" className="pr-10" {...field} />
                </div>
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="message"
          render={({ field }) => (
            <FormItem>
              <FormLabel>الرسالة</FormLabel>
              <FormControl>
                <div className="relative">
                  <MessageSquare className="absolute right-3 top-3 h-5 w-5 text-muted-foreground" />
                  <Textarea 
                    placeholder="اكتب رسالتك هنا بالتفصيل..." 
                    className="min-h-[150px] pr-10 pt-2"
                    {...field} 
                  />
                </div>
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <motion.div whileHover={{ scale: 1.01 }} whileTap={{ scale: 0.98 }}>
          <Button 
            type="submit" 
            className="w-full md:w-auto px-12 h-12 font-bold text-lg"
            disabled={isSending}
          >
            {isSending ? (
              <Loader2 className="h-5 w-5 animate-spin ml-2" />
            ) : (
              <>
                <Send className="h-5 w-5 ml-2" />
                إرسال الرسالة
              </>
            )}
          </Button>
        </motion.div>
      </form>
    </Form>
  );
}
