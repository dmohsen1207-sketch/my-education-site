import React, { useState, useEffect } from 'react';
import { Link, NavLink, useLocation } from 'react-router-dom';
import { 
  Menu, 
  X, 
  User, 
  LogOut, 
  LayoutDashboard, 
  BookOpen, 
  Cpu, 
  Layers, 
  Video, 
  Mail, 
  Info, 
  Home, 
  ChevronDown
} from 'lucide-react';
import { SiYoutube, SiInstagram, SiX, SiLinkedin } from 'react-icons/si';
import { ROUTE_PATHS } from '@/lib/index';
import { useAuth } from '@/hooks/useAuth';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { cn } from '@/lib/utils';

interface LayoutProps {
  children: React.ReactNode;
}

export function Layout({ children }: LayoutProps) {
  const { user, isAuthenticated, logout } = useAuth();
  const [isScrolled, setIsScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'الرئيسية', path: ROUTE_PATHS.HOME, icon: <Home className="w-4 h-4" /> },
    { name: 'الدورات', path: ROUTE_PATHS.COURSES, icon: <BookOpen className="w-4 h-4" /> },
    { name: 'المقالات', path: ROUTE_PATHS.ARTICLES, icon: <Layers className="w-4 h-4" /> },
    { name: 'من نحن', path: ROUTE_PATHS.ABOUT, icon: <Info className="w-4 h-4" /> },
    { name: 'تواصل معنا', path: ROUTE_PATHS.CONTACT, icon: <Mail className="w-4 h-4" /> },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground font-sans" dir="rtl">
      {/* Header */}
      <header
        className={cn(
          "fixed top-0 w-full z-50 transition-all duration-300 border-b",
          isScrolled 
            ? "bg-background/80 backdrop-blur-md border-border py-3 shadow-sm"
            : "bg-transparent border-transparent py-5"
        )}
      >
        <div className="container mx-auto px-4 flex items-center justify-between">
          {/* Logo */}
          <Link to={ROUTE_PATHS.HOME} className="flex items-center gap-2 group">
            <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center text-primary-foreground shadow-lg shadow-primary/20 group-hover:scale-105 transition-transform">
              <Cpu className="w-6 h-6" />
            </div>
            <span className="text-xl font-bold tracking-tight hidden sm:block">
              أكاديمية <span className="text-primary">الإبداع</span>
            </span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <NavLink
                key={link.path}
                to={link.path}
                className={({ isActive }) =>
                  cn(
                    "text-sm font-medium transition-colors hover:text-primary flex items-center gap-1.5",
                    isActive ? "text-primary" : "text-muted-foreground"
                  )
                }
              >
                {link.name}
              </NavLink>
            ))}
          </nav>

          {/* User Actions */}
          <div className="flex items-center gap-4">
            {isAuthenticated ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="relative h-10 w-10 rounded-full">
                    <Avatar className="h-10 w-10 border border-border">
                      <AvatarImage src={user?.avatar} alt={user?.name} />
                      <AvatarFallback className="bg-primary/10 text-primary">{user?.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="w-56" align="end" forceMount>
                  <DropdownMenuLabel className="font-normal">
                    <div className="flex flex-col space-y-1">
                      <p className="text-sm font-medium leading-none">{user?.name}</p>
                      <p className="text-xs leading-none text-muted-foreground">{user?.email}</p>
                    </div>
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <Link to={ROUTE_PATHS.DASHBOARD} className="cursor-pointer flex items-center">
                      <LayoutDashboard className="ml-2 h-4 w-4" />
                      <span>لوحة التحكم</span>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link to={ROUTE_PATHS.ABOUT} className="cursor-pointer flex items-center">
                      <User className="ml-2 h-4 w-4" />
                      <span>الملف الشخصي</span>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem 
                    className="text-destructive cursor-pointer flex items-center"
                    onClick={logout}
                  >
                    <LogOut className="ml-2 h-4 w-4" />
                    <span>تسجيل الخروج</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <div className="hidden sm:flex items-center gap-2">
                <Button variant="ghost" asChild>
                  <Link to={ROUTE_PATHS.LOGIN}>دخول</Link>
                </Button>
                <Button asChild>
                  <Link to={ROUTE_PATHS.REGISTER}>ابدأ الآن</Link>
                </Button>
              </div>
            )}

            {/* Mobile Menu Toggle */}
            <div className="md:hidden">
              <Sheet>
                <SheetTrigger asChild>
                  <Button variant="ghost" size="icon" className="shrink-0">
                    <Menu className="h-6 w-6" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="right" className="w-[300px] sm:w-[400px]">
                  <div className="flex flex-col gap-6 py-6">
                    <div className="flex items-center gap-2 mb-4">
                      <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center text-primary-foreground">
                        <Cpu className="w-5 h-5" />
                      </div>
                      <span className="text-lg font-bold">أكاديمية الإبداع</span>
                    </div>
                    <div className="flex flex-col gap-4">
                      {navLinks.map((link) => (
                        <NavLink
                          key={link.path}
                          to={link.path}
                          className={({ isActive }) =>
                            cn(
                              "flex items-center gap-3 text-lg font-medium p-2 rounded-lg transition-colors",
                              isActive ? "bg-primary/10 text-primary" : "text-muted-foreground hover:bg-muted"
                            )
                          }
                        >
                          {link.icon}
                          {link.name}
                        </NavLink>
                      ))}
                    </div>
                    <DropdownMenuSeparator />
                    {!isAuthenticated && (
                      <div className="flex flex-col gap-3 pt-4">
                        <Button variant="outline" className="w-full" asChild>
                          <Link to={ROUTE_PATHS.LOGIN}>تسجيل الدخول</Link>
                        </Button>
                        <Button className="w-full" asChild>
                          <Link to={ROUTE_PATHS.REGISTER}>إنشاء حساب جديد</Link>
                        </Button>
                      </div>
                    )}
                  </div>
                </SheetContent>
              </Sheet>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-grow pt-24 pb-12">
        {children}
      </main>

      {/* Footer */}
      <footer className="bg-card border-t py-12 md:py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
            {/* Brand Section */}
            <div className="space-y-4">
              <Link to={ROUTE_PATHS.HOME} className="flex items-center gap-2">
                <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center text-primary-foreground">
                  <Cpu className="w-5 h-5" />
                </div>
                <span className="text-xl font-bold">أكاديمية الإبداع</span>
              </Link>
              <p className="text-muted-foreground text-sm leading-relaxed">
                منصة تعليمية عربية متخصصة في تمكين الشباب العربي من إتقان مهارات المستقبل في المونتاج والتصميم والذكاء الاصطناعي.
              </p>
              <div className="flex items-center gap-4">
                <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
                  <SiYoutube className="w-5 h-5" />
                </a>
                <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
                  <SiInstagram className="w-5 h-5" />
                </a>
                <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
                  <SiX className="w-4 h-4" />
                </a>
                <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
                  <SiLinkedin className="w-5 h-5" />
                </a>
              </div>
            </div>

            {/* Quick Links */}
            <div>
              <h4 className="font-bold mb-6">روابط سريعة</h4>
              <ul className="space-y-3">
                {navLinks.map((link) => (
                  <li key={link.path}>
                    <Link 
                      to={link.path} 
                      className="text-muted-foreground hover:text-primary text-sm transition-colors"
                    >
                      {link.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            {/* Categories */}
            <div>
              <h4 className="font-bold mb-6">المسارات التعليمية</h4>
              <ul className="space-y-3">
                <li>
                  <Link to={ROUTE_PATHS.COURSES} className="text-muted-foreground hover:text-primary text-sm transition-colors flex items-center gap-2">
                    <Video className="w-3 h-3 text-primary" />
                    مونتاج فيديو
                  </Link>
                </li>
                <li>
                  <Link to={ROUTE_PATHS.COURSES} className="text-muted-foreground hover:text-primary text-sm transition-colors flex items-center gap-2">
                    <Layers className="w-3 h-3 text-primary" />
                    تصميم جرافيك
                  </Link>
                </li>
                <li>
                  <Link to={ROUTE_PATHS.COURSES} className="text-muted-foreground hover:text-primary text-sm transition-colors flex items-center gap-2">
                    <Cpu className="w-3 h-3 text-primary" />
                    ذكاء اصطناعي
                  </Link>
                </li>
              </ul>
            </div>

            {/* Contact Info */}
            <div className="space-y-6">
              <h4 className="font-bold mb-6">تواصل معنا</h4>
              <div className="flex items-center gap-3 text-sm text-muted-foreground">
                <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center shrink-0">
                  <Mail className="w-4 h-4 text-primary" />
                </div>
                <span>info@creative-academy.com</span>
              </div>
              <div className="pt-4">
                <p className="text-xs text-muted-foreground mb-4">اشترك في النشرة البريدية ليصلك جديد الدورات والمقالات</p>
                <div className="flex gap-2">
                  <input 
                    type="email" 
                    placeholder="البريد الإلكتروني" 
                    className="flex-grow h-10 px-3 rounded-md bg-muted border border-border text-xs focus:outline-none focus:ring-1 focus:ring-primary"
                  />
                  <Button size="sm">اشترك</Button>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-16 pt-8 border-t flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-xs text-muted-foreground">
              جميع الحقوق محفوظة © 2026 أكاديمية الإبداع
            </p>
            <div className="flex items-center gap-6">
              <Link to="#" className="text-xs text-muted-foreground hover:text-primary">سياسة الخصوصية</Link>
              <Link to="#" className="text-xs text-muted-foreground hover:text-primary">شروط الاستخدام</Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
