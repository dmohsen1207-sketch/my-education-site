import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  Play, 
  Users, 
  Star, 
  Clock, 
  Calendar, 
  ArrowLeft, 
  User, 
  ExternalLink, 
  BookOpen 
} from 'lucide-react';
import { 
  Course, 
  Article, 
  Instructor, 
  COURSE_LEVELS, 
  COURSE_CATEGORIES, 
  ROUTE_PATHS 
} from '@/lib/index';
import { Card, CardContent, CardFooter, CardHeader } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';

// --------------------------------------------------------------------------
// CourseCard
// --------------------------------------------------------------------------
export function CourseCard({ course }: { course: Course }) {
  const levelColor = {
    beginner: 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20',
    intermediate: 'bg-amber-500/10 text-amber-500 border-amber-500/20',
    advanced: 'bg-destructive/10 text-destructive border-destructive/20',
  };

  const categoryColor = {
    editing: 'bg-primary/10 text-primary border-primary/20',
    design: 'bg-rose-500/10 text-rose-500 border-rose-500/20',
    ai: 'bg-sky-500/10 text-sky-500 border-sky-500/20',
  };

  return (
    <motion.div
      whileHover={{ y: -8 }}
      transition={{ type: 'spring', stiffness: 300, damping: 20 }}
      className="h-full"
    >
      <Card className="overflow-hidden h-full border-border bg-card shadow-lg flex flex-col group">
        <div className="relative aspect-video overflow-hidden">
          <img
            src={course.image}
            alt={course.title}
            className="object-cover w-full h-full transition-transform duration-500 group-hover:scale-110"
          />
          <Badge 
            className={`absolute top-3 right-3 border ${categoryColor[course.category]}`}
            variant="outline"
          >
            {COURSE_CATEGORIES[course.category]}
          </Badge>
          <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
            <Play className="w-12 h-12 text-white fill-white" />
          </div>
        </div>

        <CardContent className="p-5 flex-grow">
          <div className="flex items-center justify-between mb-3">
            <Badge 
              variant="secondary" 
              className={`text-[10px] font-medium uppercase tracking-wider ${levelColor[course.level]}`}
            >
              {COURSE_LEVELS[course.level]}
            </Badge>
            <div className="flex items-center gap-1 text-amber-400">
              <Star className="w-4 h-4 fill-amber-400" />
              <span className="text-sm font-bold">{course.rating}</span>
            </div>
          </div>

          <h3 className="text-xl font-bold mb-2 line-clamp-2 leading-tight text-foreground">
            {course.title}
          </h3>
          
          <p className="text-muted-foreground text-sm line-clamp-2 mb-4">
            {course.description}
          </p>

          <div className="flex items-center gap-4 text-xs text-muted-foreground mt-auto">
            <div className="flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5" />
              <span>{course.duration}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Users className="w-3.5 h-3.5" />
              <span>{course.studentsCount} طالب</span>
            </div>
          </div>
        </CardContent>

        <CardFooter className="px-5 pb-5 pt-0 flex items-center justify-between border-t border-border/50 pt-4">
          <div className="text-lg font-bold text-primary">
            {course.price === 'free' ? 'مجاني' : `${course.price} $`}
          </div>
          <Button asChild size="sm" className="gap-2">
            <Link to={ROUTE_PATHS.COURSE_DETAIL.replace(':id', course.id)}>
              تفاصيل الدورة
              <ArrowLeft className="w-4 h-4" />
            </Link>
          </Button>
        </CardFooter>
      </Card>
    </motion.div>
  );
}

// --------------------------------------------------------------------------
// ArticleCard
// --------------------------------------------------------------------------
export function ArticleCard({ article }: { article: Article }) {
  return (
    <motion.div
      whileHover={{ y: -5 }}
      transition={{ type: 'spring', stiffness: 300, damping: 20 }}
    >
      <Card className="overflow-hidden border-border bg-card group cursor-pointer">
        <div className="relative aspect-[16/9] overflow-hidden">
          <img
            src={article.image}
            alt={article.title}
            className="object-cover w-full h-full transition-transform duration-700 group-hover:scale-105"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background/80 to-transparent" />
          <Badge className="absolute bottom-3 right-3 bg-primary/90 hover:bg-primary">
            {article.category}
          </Badge>
        </div>

        <CardContent className="p-5">
          <div className="flex items-center gap-4 text-xs text-muted-foreground mb-3">
            <div className="flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5" />
              <span>{article.date}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5" />
              <span>{article.readTime}</span>
            </div>
          </div>

          <h3 className="text-lg font-bold mb-2 group-hover:text-primary transition-colors leading-snug">
            {article.title}
          </h3>
          
          <p className="text-muted-foreground text-sm line-clamp-2">
            {article.excerpt}
          </p>
        </CardContent>

        <CardFooter className="px-5 pb-5 pt-0">
          <Link 
            to={ROUTE_PATHS.ARTICLES} 
            className="text-primary text-sm font-semibold flex items-center gap-2 group-hover:gap-3 transition-all"
          >
            اقرأ المزيد
            <ArrowLeft className="w-4 h-4" />
          </Link>
        </CardFooter>
      </Card>
    </motion.div>
  );
}

// --------------------------------------------------------------------------
// InstructorCard
// --------------------------------------------------------------------------
export function InstructorCard({ instructor }: { instructor: any }) {
  const data = instructor as Instructor;
  
  return (
    <Card className="border-border bg-card p-6 flex flex-col items-center text-center group hover:border-primary/50 transition-colors">
      <div className="relative mb-4">
        <div className="w-24 h-24 rounded-full overflow-hidden border-2 border-primary/20 p-1 group-hover:border-primary transition-colors">
          <img
            src={data.avatar}
            alt={data.name}
            className="w-full h-full object-cover rounded-full"
          />
        </div>
        <div className="absolute -bottom-1 -right-1 bg-primary text-primary-foreground p-1.5 rounded-full">
          <User className="w-3 h-3" />
        </div>
      </div>

      <h3 className="text-lg font-bold text-foreground mb-1">{data.name}</h3>
      <p className="text-primary text-sm font-medium mb-3">{data.role}</p>
      
      <p className="text-muted-foreground text-sm line-clamp-3 mb-6">
        {data.bio}
      </p>

      <div className="grid grid-cols-2 gap-4 w-full border-t border-border pt-6">
        <div className="flex flex-col items-center">
          <span className="text-xl font-bold text-foreground">{data.coursesCount}</span>
          <span className="text-xs text-muted-foreground flex items-center gap-1">
            <BookOpen className="w-3 h-3" />
            دورة
          </span>
        </div>
        <div className="flex flex-col items-center">
          <span className="text-xl font-bold text-foreground">{data.studentsCount.toLocaleString()}+</span>
          <span className="text-xs text-muted-foreground flex items-center gap-1">
            <Users className="w-3 h-3" />
            طالب
          </span>
        </div>
      </div>

      <Button variant="ghost" size="sm" className="mt-6 w-full group/btn">
        عرض الملف الشخصي
        <ExternalLink className="ms-2 w-3.5 h-3.5 opacity-0 group-hover/btn:opacity-100 transition-opacity" />
      </Button>
    </Card>
  );
}
