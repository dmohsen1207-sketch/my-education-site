import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, Newspaper, Filter, BookOpen, ArrowLeft } from 'lucide-react';
import { Article } from '@/lib/index';
import { articles } from '@/data/index';
import { ArticleCard } from '@/components/Cards';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

const springTransition = {
  type: "spring",
  stiffness: 300,
  damping: 30
};

const fadeInUp = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0 }
};

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1
    }
  }
};

export default function Articles() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('الكل');

  const categories = ['الكل', ...new Set(articles.map(a => a.category))];

  const filteredArticles = articles.filter(article => {
    const matchesSearch = article.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          article.excerpt.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          article.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesCategory = selectedCategory === 'الكل' || article.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="min-h-screen bg-background" dir="rtl">
      {/* Hero Header */}
      <section className="relative pt-24 pb-16 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-primary/10 via-background to-background z-0" />
        <div className="container mx-auto px-4 relative z-10">
          <motion.div
            initial="hidden"
            animate="visible"
            variants={fadeInUp}
            transition={springTransition}
            className="max-w-3xl text-right"
          >
            <Badge variant="outline" className="mb-4 border-primary/30 text-primary bg-primary/5 py-1 px-3">
              <Newspaper className="w-3.5 h-3.5 ml-2" />
              المدونة والمعرفة
            </Badge>
            <h1 className="text-4xl md:text-5xl font-bold mb-6 tracking-tight">
              اكتشف عالم <span className="text-primary">الإبداع الرقمي</span>
            </h1>
            <p className="text-lg text-muted-foreground leading-relaxed">
              نشاركك أحدث المقالات، النصائح، والدروس في مجالات المونتاج، التصميم، والذكاء الاصطناعي لمساعدتك على التفوق في رحلتك الإبداعية.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Filter Bar */}
      <section className="container mx-auto px-4 -mt-10 relative z-20">
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-card border border-border/50 rounded-2xl p-4 md:p-6 shadow-2xl shadow-primary/5 backdrop-blur-xl"
        >
          <div className="flex flex-col lg:flex-row gap-6 items-center justify-between">
            <div className="relative w-full lg:max-w-md">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <Input
                type="text"
                placeholder="ابحث عن مقال، تقنية، أو نصيحة..."
                className="pr-10 bg-background/50 border-border focus:ring-primary h-12 rounded-xl"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>

            <div className="flex flex-wrap items-center justify-center gap-2">
              <div className="flex items-center gap-2 ml-4 text-muted-foreground text-sm font-medium">
                <Filter className="w-4 h-4" />
                <span>التصنيف:</span>
              </div>
              {categories.map((cat) => (
                <Button
                  key={cat}
                  variant={selectedCategory === cat ? "default" : "ghost"}
                  size="sm"
                  onClick={() => setSelectedCategory(cat)}
                  className={`rounded-full px-5 transition-all ${
                    selectedCategory === cat 
                      ? "shadow-lg shadow-primary/20"
                      : "hover:bg-accent"
                  }`}
                >
                  {cat}
                </Button>
              ))}
            </div>
          </div>
        </motion.div>
      </section>

      {/* Articles Grid */}
      <section className="container mx-auto px-4 py-16">
        <AnimatePresence mode="wait">
          {filteredArticles.length > 0 ? (
            <motion.div
              key="grid"
              variants={staggerContainer}
              initial="hidden"
              animate="visible"
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
            >
              {filteredArticles.map((article) => (
                <motion.div
                  key={article.id}
                  variants={fadeInUp}
                  transition={springTransition}
                  layout
                >
                  <ArticleCard article={article} />
                </motion.div>
              ))}
            </motion.div>
          ) : (
            <motion.div
              key="empty"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex flex-col items-center justify-center py-20 text-center"
            >
              <div className="w-24 h-24 bg-muted rounded-full flex items-center justify-center mb-6">
                <BookOpen className="w-10 h-10 text-muted-foreground/50" />
              </div>
              <h3 className="text-2xl font-bold mb-2">لا توجد مقالات تطابق بحثك</h3>
              <p className="text-muted-foreground max-w-md">
                لم نتمكن من العثور على أي مقالات تطابق الكلمات المفتاحية أو التصنيفات المختارة. جرب البحث عن شيء آخر.
              </p>
              <Button 
                variant="outline" 
                className="mt-8 rounded-full"
                onClick={() => { setSearchTerm(''); setSelectedCategory('الكل'); }}
              >
                عرض جميع المقالات
              </Button>
            </motion.div>
          )}
        </AnimatePresence>
      </section>

      {/* CTA Section */}
      <section className="container mx-auto px-4 pb-24">
        <div className="relative rounded-[2rem] overflow-hidden bg-primary p-12 text-center text-primary-foreground">
          <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-10" />
          <div className="relative z-10 max-w-2xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">هل لديك مهارة تود مشاركتها؟</h2>
            <p className="text-primary-foreground/80 mb-8 text-lg">
              نحن نرحب دائماً بالخبراء والمبدعين للمساهمة في إثراء المحتوى العربي. تواصل معنا لمناقشة إمكانية النشر في مدونتنا.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Button size="lg" variant="secondary" className="rounded-full px-8 font-bold">
                تواصل معنا
              </Button>
              <Button size="lg" variant="outline" className="rounded-full px-8 bg-transparent border-white/20 hover:bg-white/10">
                تصفح الدورات
              </Button>
            </div>
          </div>
          {/* Decorative Elements */}
          <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full blur-3xl -mr-16 -mt-16" />
          <div className="absolute bottom-0 left-0 w-32 h-32 bg-white/10 rounded-full blur-3xl -ml-16 -mb-16" />
        </div>
      </section>
    </div>
  );
}
