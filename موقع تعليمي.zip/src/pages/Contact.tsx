import { motion } from "framer-motion";
import { Mail, Phone, MapPin, MessageSquare, Globe } from "lucide-react";
import { SiX, SiLinkedin, SiYoutube, SiInstagram } from "react-icons/si";
import { ContactForm } from "@/components/Forms";

const contactDetails = [
  {
    icon: Mail,
    title: "البريد الإلكتروني",
    value: "support@academy.com",
    description: "راسلنا في أي وقت وسنرد عليك خلال 24 ساعة.",
    color: "text-blue-500",
  },
  {
    icon: Phone,
    title: "رقم الهاتف",
    value: "+966 50 123 4567",
    description: "متاحون من الأحد إلى الخميس، 9 صباحاً - 5 مساءً.",
    color: "text-emerald-500",
  },
  {
    icon: MapPin,
    title: "المقر الرئيسي",
    value: "الرياض، المملكة العربية السعودية",
    description: "حي الصحافة، طريق الملك فهد.",
    color: "text-orange-500",
  },
];

const socialLinks = [
  { icon: SiX, href: "#", label: "Twitter/X" },
  { icon: SiLinkedin, href: "#", label: "LinkedIn" },
  { icon: SiYoutube, href: "#", label: "YouTube" },
  { icon: SiInstagram, href: "#", label: "Instagram" },
];

export default function Contact() {
  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="relative py-20 overflow-hidden border-b border-border">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5 -z-10" />
        <div className="container mx-auto px-4 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              تواصل <span className="text-primary">معنا</span>
            </h1>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              لديك استفسار حول الدورات؟ أو تحتاج مساعدة تقنية؟ نحن هنا لمساعدتك في رحلتك التعليمية.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
            {/* Contact Information */}
            <div className="lg:col-span-5 space-y-8">
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                className="space-y-6"
              >
                <div className="flex items-center gap-3 text-primary mb-2">
                  <MessageSquare className="w-6 h-6" />
                  <span className="font-bold text-lg">معلومات التواصل</span>
                </div>
                
                <div className="grid gap-6">
                  {contactDetails.map((item, index) => (
                    <div 
                      key={index} 
                      className="flex gap-4 p-5 rounded-2xl bg-card border border-border/50 hover:border-primary/30 transition-colors"
                    >
                      <div className={`p-3 rounded-xl bg-muted ${item.color}`}>
                        <item.icon className="w-6 h-6" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-foreground">{item.title}</h3>
                        <p className="text-primary font-medium text-sm my-1" dir="ltr">{item.value}</p>
                        <p className="text-muted-foreground text-xs">{item.description}</p>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="pt-8">
                  <h3 className="font-semibold mb-4 flex items-center gap-2">
                    <Globe className="w-5 h-5 text-primary" />
                    تابعنا على المنصات الاجتماعية
                  </h3>
                  <div className="flex gap-4">
                    {socialLinks.map((social, idx) => (
                      <a
                        key={idx}
                        href={social.href}
                        aria-label={social.label}
                        className="p-3 rounded-full bg-muted hover:bg-primary hover:text-primary-foreground transition-all duration-300"
                      >
                        <social.icon className="w-5 h-5" />
                      </a>
                    ))}
                  </div>
                </div>
              </motion.div>
            </div>

            {/* Contact Form Container */}
            <div className="lg:col-span-7">
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                className="bg-card p-8 rounded-3xl border border-border shadow-xl shadow-primary/5"
              >
                <div className="mb-8">
                  <h2 className="text-2xl font-bold mb-2">أرسل لنا رسالة</h2>
                  <p className="text-muted-foreground">املأ النموذج أدناه وسيقوم فريقنا بالتواصل معك في أقرب وقت.</p>
                </div>
                
                <ContactForm />
              </motion.div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Quick Link Section */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-2xl font-bold mb-4">هل لديك أسئلة شائعة؟</h2>
          <p className="text-muted-foreground mb-8">
            ربما تجد الإجابة التي تبحث عنها في صفحة الأسئلة المتكررة أو المقالات التعليمية.
          </p>
          <div className="flex justify-center gap-4">
            <button className="px-8 py-3 bg-primary text-primary-foreground rounded-full font-medium hover:opacity-90 transition-opacity">
              تصفح المقالات
            </button>
            <button className="px-8 py-3 bg-background border border-border rounded-full font-medium hover:bg-accent transition-colors">
              مركز المساعدة
            </button>
          </div>
        </div>
      </section>

      {/* Map Placeholder */}
      <section className="h-[400px] w-full bg-muted relative">
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center">
            <MapPin className="w-12 h-12 text-muted-foreground/30 mx-auto mb-4" />
            <p className="text-muted-foreground font-medium">الخريطة التفاعلية ستظهر هنا</p>
          </div>
        </div>
        {/* In a real production app, you would integrate Google Maps or Leaflet here */}
        <div className="absolute inset-0 bg-gradient-to-t from-background to-transparent pointer-events-none" />
      </section>
    </div>
  );
}
