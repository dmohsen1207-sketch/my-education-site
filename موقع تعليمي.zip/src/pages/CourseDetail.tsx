import React from "react";
import { useParams, Link } from "react-router-dom";
import { motion } from "framer-motion";
import {
  Play,
  Clock,
  Star,
  Users,
  CheckCircle2,
  ChevronRight,
  Lock,
  Wrench,
  Award,
  Info,
  BookOpen
} from "lucide-react";
import {
  COURSE_LEVELS,
  COURSE_CATEGORIES,
  ROUTE_PATHS,
  Course,
  Instructor
} from "@/lib/index";
import { courses, instructors } from "@/data/index";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { springPresets, fadeInUp, staggerContainer, staggerItem } from "@/lib/motion";

export default function CourseDetail() {
  const { id } = useParams<{ id: string }>();
  const course = courses.find((c) => c.id === id);

  if (!course) {
    return (
      <div className="min-h-[70vh] flex flex-col items-center justify-center gap-4 text-center px-4">
        <h2 className="text-3xl font-bold">الدورة غير موجودة</h2>
        <p className="text-muted-foreground">عذراً، لم نتمكن من العثور على الدورة التي تبحث عنها.</p>
        <Link to={ROUTE_PATHS.COURSES}>
          <Button variant="default">
            العودة لجميع الدورات
          </Button>
        </Link>
      </div>
    );
  }

  const instructor = instructors.find((inst) => inst.id === course.instructorId);

  return (
    <div className="min-h-screen pb-20" dir="rtl">
      {/* Hero Section */}
      <section className="relative bg-muted/30 pt-16 pb-32 overflow-hidden">
        <div className="absolute inset-0 z-0 opacity-10">
          <img 
            src={course.image} 
            alt="background" 
            className="w-full h-full object-cover blur-xl scale-110"
          />
        </div>
        
        <div className="container mx-auto px-4 relative z-10">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={springPresets.gentle}
            className="flex flex-col gap-6 max-w-4xl"
          >
            <div className="flex flex-wrap gap-2">
              <Badge variant="secondary" className="px-3 py-1">
                {COURSE_CATEGORIES[course.category]}
              </Badge>
              <Badge variant="outline" className="px-3 py-1 bg-background/50 backdrop-blur-sm border-primary/20">
                {COURSE_LEVELS[course.level]}
              </Badge>
            </div>

            <h1 className="text-3xl md:text-5xl font-bold text-foreground leading-tight">
              {course.title}
            </h1>

            <p className="text-lg text-muted-foreground leading-relaxed">
              {course.description}
            </p>

            <div className="flex flex-wrap items-center gap-6 text-sm text-muted-foreground">
              <div className="flex items-center gap-2">
                <Star className="w-5 h-5 text-yellow-500 fill-yellow-500" />
                <span className="font-bold text-foreground">{course.rating}</span>
                <span>(250+ تقييم)</span>
              </div>
              <div className="flex items-center gap-2">
                <Users className="w-5 h-5 text-primary" />
                <span>{course.studentsCount.toLocaleString()} طالب مشترك</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-primary" />
                <span>مدة الدورة: {course.duration}</span>
              </div>
            </div>

            {instructor && (
              <div className="flex items-center gap-3 mt-4">
                <img 
                  src={instructor.avatar} 
                  alt={instructor.name} 
                  className="w-12 h-12 rounded-full border-2 border-primary/20 object-cover"
                />
                <div>
                  <p className="text-xs text-muted-foreground">بإشراف المدرب</p>
                  <p className="font-semibold">{instructor.name}</p>
                </div>
              </div>
            )}
          </motion.div>
        </div>
      </section>

      {/* Content Section */}
      <div className="container mx-auto px-4 -mt-16 relative z-20">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Main Column */}
          <div className="lg:col-span-2 space-y-8">
            <Tabs defaultValue="overview" className="w-full">
              <TabsList className="grid w-full grid-cols-3 h-12 mb-8">
                <TabsTrigger value="overview" className="text-base">نظرة عامة</TabsTrigger>
                <TabsTrigger value="curriculum" className="text-base">المحتوى الدراسي</TabsTrigger>
                <TabsTrigger value="instructor" className="text-base">المدرب</TabsTrigger>
              </TabsList>

              <TabsContent value="overview" className="space-y-10">
                {/* What You Will Learn */}
                <Card className="border-none shadow-sm bg-card/50">
                  <CardContent className="p-8">
                    <h3 className="text-xl font-bold mb-6 flex items-center gap-2">
                      <CheckCircle2 className="text-primary" />
                      ماذا ستتعلم في هذه الدورة؟
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {course.whatYouWillLearn.map((item, idx) => (
                        <div key={idx} className="flex items-start gap-3">
                          <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0 mt-0.5" />
                          <span className="text-muted-foreground">{item}</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                {/* Detailed Description */}
                <div className="space-y-4">
                  <h3 className="text-2xl font-bold">وصف الدورة</h3>
                  <div className="prose prose-invert max-w-none text-muted-foreground leading-loose">
                    <p className="whitespace-pre-line">
                      {course.longDescription || course.description}
                    </p>
                  </div>
                </div>

                {/* Requirements */}
                <div className="space-y-4">
                  <h3 className="text-xl font-bold">المتطلبات الأساسية</h3>
                  <ul className="space-y-3">
                    {course.requirements.map((req, idx) => (
                      <li key={idx} className="flex items-center gap-3 text-muted-foreground">
                        <div className="w-1.5 h-1.5 rounded-full bg-primary shrink-0" />
                        {req}
                      </li>
                    ))}
                  </ul>
                </div>
              </TabsContent>

              <TabsContent value="curriculum" className="space-y-6">
                <div className="flex items-center justify-between">
                  <h3 className="text-2xl font-bold">منهج الدورة</h3>
                  <span className="text-sm text-muted-foreground">
                    {course.lessons.length} دروس • {course.duration}
                  </span>
                </div>

                {course.lessons.length > 0 ? (
                  <Accordion type="single" collapsible className="w-full space-y-4">
                    <AccordionItem value="module-1" className="border rounded-xl px-4 bg-card">
                      <AccordionTrigger className="hover:no-underline">
                        <div className="flex items-center gap-3">
                          <BookOpen className="w-5 h-5 text-primary" />
                          <span className="text-lg font-semibold">المحتوى التعليمي</span>
                        </div>
                      </AccordionTrigger>
                      <AccordionContent className="space-y-2 pb-4">
                        {course.lessons.map((lesson) => (
                          <div 
                            key={lesson.id} 
                            className="flex items-center justify-between p-3 rounded-lg hover:bg-muted/50 transition-colors group"
                          >
                            <div className="flex items-center gap-4">
                              {lesson.isFree ? (
                                <Play className="w-4 h-4 text-primary" />
                              ) : (
                                <Lock className="w-4 h-4 text-muted-foreground" />
                              )}
                              <div>
                                <p className="font-medium group-hover:text-primary transition-colors">
                                  {lesson.title}
                                </p>
                                <span className="text-xs text-muted-foreground">
                                  {lesson.duration}
                                </span>
                              </div>
                            </div>
                            {lesson.isFree ? (
                              <Badge variant="secondary" className="bg-emerald-500/10 text-emerald-500 border-none">
                                معاينة مجانية
                              </Badge>
                            ) : (
                              <Button variant="ghost" size="sm" disabled className="text-xs">
                                مغلق
                              </Button>
                            )}
                          </div>
                        ))}
                      </AccordionContent>
                    </AccordionItem>
                  </Accordion>
                ) : (
                  <div className="p-12 text-center bg-muted/20 rounded-2xl border border-dashed">
                    <Info className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                    <p className="text-muted-foreground">سيتم إضافة الدروس قريباً</p>
                  </div>
                )}
              </TabsContent>

              <TabsContent value="instructor" className="space-y-6">
                {instructor ? (
                  <Card className="border-none bg-card/50 overflow-hidden">
                    <CardContent className="p-8 flex flex-col md:flex-row gap-8">
                      <img 
                        src={instructor.avatar} 
                        alt={instructor.name} 
                        className="w-32 h-32 md:w-48 md:h-48 rounded-2xl object-cover shadow-lg"
                      />
                      <div className="flex-1 space-y-4">
                        <div>
                          <h3 className="text-2xl font-bold">{instructor.name}</h3>
                          <p className="text-primary font-medium">{instructor.role}</p>
                        </div>
                        <p className="text-muted-foreground leading-relaxed">
                          {instructor.bio}
                        </p>
                        <div className="flex items-center gap-8">
                          <div className="text-center md:text-right">
                            <p className="text-2xl font-bold">{instructor.studentsCount.toLocaleString()}</p>
                            <p className="text-xs text-muted-foreground">طالب</p>
                          </div>
                          <div className="text-center md:text-right">
                            <p className="text-2xl font-bold">{instructor.coursesCount}</p>
                            <p className="text-xs text-muted-foreground">دورات</p>
                          </div>
                          <div className="text-center md:text-right">
                            <p className="text-2xl font-bold">4.9</p>
                            <p className="text-xs text-muted-foreground">تقييم</p>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ) : (
                  <p>معلومات المدرب غير متوفرة</p>
                )}
              </TabsContent>
            </Tabs>
          </div>

          {/* Sidebar Column */}
          <div className="lg:col-span-1">
            <div className="sticky top-24 space-y-6">
              <Card className="border-none shadow-2xl overflow-hidden">
                <div className="aspect-video relative group">
                  <img 
                    src={course.image} 
                    alt={course.title} 
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <div className="w-16 h-16 rounded-full bg-white flex items-center justify-center">
                      <Play className="w-8 h-8 text-primary fill-primary ms-1" />
                    </div>
                  </div>
                </div>
                <CardContent className="p-6 space-y-6">
                  <div className="flex items-center justify-between">
                    <span className="text-3xl font-bold text-foreground">
                      {course.price === "free" ? "مجاناً" : `${course.price}$`}
                    </span>
                    {course.price !== "free" && (
                      <span className="text-muted-foreground line-through">{Number(course.price) * 1.5}$</span>
                    )}
                  </div>

                  <div className="space-y-3">
                    <Button className="w-full h-12 text-lg font-bold shadow-lg shadow-primary/20">
                      سجل الآن في الدورة
                    </Button>
                    <Button variant="outline" className="w-full h-12">
                      إضافة إلى المفضلة
                    </Button>
                  </div>

                  <p className="text-xs text-center text-muted-foreground">
                    ضمان استرداد الأموال لمدة 30 يوماً
                  </p>

                  <div className="pt-6 border-t">
                    <h4 className="font-bold mb-4">تتضمن هذه الدورة:</h4>
                    <ul className="space-y-3">
                      <li className="flex items-center gap-3 text-sm">
                        <Play className="w-4 h-4 text-primary" />
                        <span>{course.duration} من المحتوى المرئي</span>
                      </li>
                      <li className="flex items-center gap-3 text-sm">
                        <Award className="w-4 h-4 text-primary" />
                        <span>شهادة إتمام معتمدة</span>
                      </li>
                      <li className="flex items-center gap-3 text-sm">
                        <Wrench className="w-4 h-4 text-primary" />
                        <span>ملفات تدريبية ومشاريع</span>
                      </li>
                    </ul>
                  </div>
                </CardContent>
              </Card>

              {/* Tools Card */}
              {course.tools.length > 0 && (
                <Card className="border-none bg-muted/30">
                  <CardContent className="p-6">
                    <h4 className="font-bold mb-4 flex items-center gap-2">
                      <Wrench className="w-4 h-4" />
                      الأدوات المستخدمة
                    </h4>
                    <div className="flex flex-wrap gap-2">
                      {course.tools.map((tool, idx) => (
                        <Badge key={idx} variant="secondary" className="bg-background">
                          {tool}
                        </Badge>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}
