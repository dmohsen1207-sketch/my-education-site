import React, { useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  BookOpen,
  CheckCircle,
  Clock,
  LayoutDashboard,
  LogOut,
  Settings,
  Award,
  TrendingUp,
  PlayCircle
} from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { courses } from '@/data/index';
import { CourseCard } from '@/components/Cards';
import { ROUTE_PATHS, Course } from '@/lib/index';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { springPresets, fadeInUp, staggerContainer, staggerItem } from '@/lib/motion';

export default function Dashboard() {
  const { user, isAuthenticated, isLoading, logout } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      navigate(ROUTE_PATHS.LOGIN);
    }
  }, [isLoading, isAuthenticated, navigate]);

  if (isLoading || !user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
          className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full"
        />
      </div>
    );
  }

  const enrolledCourses = courses.filter((c) => user.enrolledCourses.includes(c.id));
  const recommendedCourses = courses.filter((c) => !user.enrolledCourses.includes(c.id)).slice(0, 3);

  // Calculate simple mock progress based on user.completedLessons
  const calculateProgress = (course: Course) => {
    if (!course.lessons || course.lessons.length === 0) return 0;
    const completedInThisCourse = course.lessons.filter(l => user.completedLessons.includes(l.id)).length;
    return Math.round((completedInThisCourse / course.lessons.length) * 100);
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Dashboard Header */}
      <div className="bg-card border-b border-border/50 py-10">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-4">
              <Avatar className="h-20 w-20 border-2 border-primary/20">
                <AvatarImage src={user.avatar} alt={user.name} />
                <AvatarFallback className="text-2xl bg-primary/10 text-primary">
                  {user.name.charAt(0)}
                </AvatarFallback>
              </Avatar>
              <div className="text-center md:text-right">
                <h1 className="text-2xl md:text-3xl font-bold mb-1">مرحباً بك مجدداً، {user.name} 👋</h1>
                <p className="text-muted-foreground">استمر في رحلة تعلمك وطور مهاراتك اليوم.</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Button variant="outline" size="sm" className="gap-2">
                <Settings className="w-4 h-4" />
                الإعدادات
              </Button>
              <Button variant="destructive" size="sm" className="gap-2" onClick={logout}>
                <LogOut className="w-4 h-4" />
                تسجيل الخروج
              </Button>
            </div>
          </div>

          {/* Stats Overview */}
          <motion.div 
            variants={staggerContainer} 
            initial="hidden" 
            animate="visible"
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-10"
          >
            <motion.div variants={staggerItem}>
              <Card className="bg-primary/5 border-primary/10">
                <CardContent className="p-6 flex items-center gap-4">
                  <div className="p-3 bg-primary/10 rounded-xl text-primary">
                    <BookOpen className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">الدورات المسجلة</p>
                    <p className="text-2xl font-bold">{user.enrolledCourses.length}</p>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div variants={staggerItem}>
              <Card className="bg-emerald-500/5 border-emerald-500/10">
                <CardContent className="p-6 flex items-center gap-4">
                  <div className="p-3 bg-emerald-500/10 rounded-xl text-emerald-500">
                    <CheckCircle className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">الدروس المكتملة</p>
                    <p className="text-2xl font-bold">{user.completedLessons.length}</p>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div variants={staggerItem}>
              <Card className="bg-amber-500/5 border-amber-500/10">
                <CardContent className="p-6 flex items-center gap-4">
                  <div className="p-3 bg-amber-500/10 rounded-xl text-amber-500">
                    <Award className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">النقاط المكتسبة</p>
                    <p className="text-2xl font-bold">1,250</p>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div variants={staggerItem}>
              <Card className="bg-indigo-500/5 border-indigo-500/10">
                <CardContent className="p-6 flex items-center gap-4">
                  <div className="p-3 bg-indigo-500/10 rounded-xl text-indigo-500">
                    <TrendingUp className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">ساعات التعلم</p>
                    <p className="text-2xl font-bold">24.5</p>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </motion.div>
        </div>
      </div>

      <main className="container mx-auto px-4 py-12">
        <Tabs defaultValue="my-courses" className="w-full">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-8 gap-4">
            <TabsList className="grid grid-cols-2 w-full md:w-[400px]">
              <TabsTrigger value="my-courses" className="gap-2">
                <LayoutDashboard className="w-4 h-4" />
                دوراتي الحالية
              </TabsTrigger>
              <TabsTrigger value="activity" className="gap-2">
                <Clock className="w-4 h-4" />
                النشاط الأخير
              </TabsTrigger>
            </TabsList>
            <Link to={ROUTE_PATHS.COURSES}>
              <Button variant="link" className="text-primary">تصفح جميع الدورات ←</Button>
            </Link>
          </div>

          <TabsContent value="my-courses" className="space-y-8">
            {enrolledCourses.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-8">
                {enrolledCourses.map((course) => (
                  <motion.div 
                    key={course.id} 
                    initial="hidden" 
                    animate="visible" 
                    variants={fadeInUp}
                    className="group"
                  >
                    <div className="relative">
                      <CourseCard course={course} />
                      <div className="absolute -bottom-4 left-4 right-4 bg-card border border-border/50 rounded-xl p-4 shadow-lg">
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-xs font-medium text-muted-foreground">التقدم: {calculateProgress(course)}%</span>
                          <PlayCircle className="w-4 h-4 text-primary opacity-0 group-hover:opacity-100 transition-opacity" />
                        </div>
                        <Progress value={calculateProgress(course)} className="h-1.5" />
                      </div>
                    </div>
                    <div className="mt-8"></div>
                  </motion.div>
                ))}
              </div>
            ) : (
              <Card className="bg-muted/30 border-dashed">
                <CardContent className="p-12 text-center flex flex-col items-center">
                  <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mb-4">
                    <BookOpen className="w-8 h-8 text-muted-foreground" />
                  </div>
                  <h3 className="text-xl font-bold mb-2">لا توجد دورات مسجلة بعد</h3>
                  <p className="text-muted-foreground mb-6 max-w-md">
                    ابدأ رحلتك التعليمية الآن واختر من بين أفضل الدورات في المونتاج والتصميم والذكاء الاصطناعي.
                  </p>
                  <Link to={ROUTE_PATHS.COURSES}>
                    <Button size="lg">استكشف الدورات</Button>
                  </Link>
                </CardContent>
              </Card>
            )}

            {/* Recommendations Section */}
            <div className="mt-20">
              <div className="flex items-center justify-between mb-8">
                <h2 className="text-2xl font-bold">دورات مقترحة لك</h2>
                <TrendingUp className="w-6 h-6 text-primary" />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {recommendedCourses.map((course) => (
                  <CourseCard key={course.id} course={course} />
                ))}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="activity">
            <Card>
              <CardHeader>
                <CardTitle>النشاط الأخير</CardTitle>
                <CardDescription>سجل نشاطك التعليمي خلال الـ 30 يوماً الماضية</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {user.completedLessons.length > 0 ? (
                  user.completedLessons.map((lessonId, index) => (
                    <div key={index} className="flex items-center gap-4 pb-4 border-b border-border last:border-0">
                      <div className="w-10 h-10 rounded-full bg-emerald-500/10 text-emerald-500 flex items-center justify-center shrink-0">
                        <CheckCircle className="w-5 h-5" />
                      </div>
                      <div>
                        <p className="font-medium">أكملت درساً بنجاح</p>
                        <p className="text-sm text-muted-foreground">معرف الدرس: {lessonId}</p>
                      </div>
                      <div className="mr-auto text-xs text-muted-foreground">
                        منذ يومين
                      </div>
                    </div>
                  ))
                ) : (
                  <p className="text-center text-muted-foreground py-10">لا يوجد نشاط مسجل حتى الآن.</p>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
