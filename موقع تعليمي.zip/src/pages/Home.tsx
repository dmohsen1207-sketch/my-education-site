import React from "react";
import { motion } from "framer-motion";
import { 
  PlayCircle, 
  Sparkles, 
  Palette, 
  Cpu, 
  Users, 
  Star, 
  ArrowLeft, 
  Zap, 
  ShieldCheck,
  Globe
} from "lucide-react";
import { Link } from "react-router-dom";
import { ROUTE_PATHS } from "@/lib/index";
import { courses, articles } from "@/data/index";
import { CourseCard, ArticleCard } from "@/components/Cards";
import { IMAGES } from "@/assets/images";
import { Button } from "@/components/ui/button";
import { springPresets, fadeInUp, staggerContainer, staggerItem } from "@/lib/motion";

export default function Home() {
  const featuredCourses = courses.slice(0, 3);
  const recentArticles = articles.slice(0, 3);

  return (
    <div className="flex flex-col gap-0">
      {/* Hero Section */}
      <section 
        id="hero" 
        className="relative min-h-[90vh] flex items-center overflow-hidden pt-20"
      >
        <div className="absolute inset-0 z-0">
          <img 
            src={IMAGES.ONLINE_LEARNING_1} 
            alt="Hero Background" 
            className="w-full h-full object-cover opacity-20"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-background via-background/80 to-background" />
        </div>

        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-3xl">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={springPresets.gentle}
            >
              <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-primary/10 text-primary text-sm font-medium mb-6 border border-primary/20">
                <Sparkles className="w-4 h-4" />
                منصة المستقبل للمبدعين العرب
              </span>
              <h1 className="text-5xl md:text-7xl font-bold leading-tight mb-6">
                أتقن مهارات <span className="text-primary">المستقبل</span> الرقمية
              </h1>
              <p className="text-xl text-muted-foreground mb-8 leading-relaxed">
                انطلق في رحلتك التعليمية لتعلم المونتاج، التصميم، والذكاء الاصطناعي مع نخبة من الخبراء في الوطن العربي. دورات عملية مصممة لتبدأ مسيرتك المهنية فوراً.
              </p>
              <div className="flex flex-wrap gap-4">
                <Button asChild size="lg" className="h-14 px-8 text-lg rounded-xl">
                  <Link to={ROUTE_PATHS.COURSES}>
                    تصفح الدورات
                    <PlayCircle className="me-2 h-5 w-5" />
                  </Link>
                </Button>
                <Button asChild variant="outline" size="lg" className="h-14 px-8 text-lg rounded-xl border-primary/20 hover:bg-primary/5">
                  <Link to={ROUTE_PATHS.ABOUT}>
                    تعرف علينا
                  </Link>
                </Button>
              </div>

              <div className="mt-12 flex items-center gap-6">
                <div className="flex -space-x-3 rtl:space-x-reverse">
                  {[1, 2, 3, 4].map((i) => (
                    <div key={i} className="w-10 h-10 rounded-full border-2 border-background bg-muted overflow-hidden">
                      <img src={`https://i.pravatar.cc/100?img=${i + 10}`} alt="User" />
                    </div>
                  ))}
                </div>
                <div className="text-sm">
                  <div className="flex items-center gap-1 text-yellow-500">
                    <Star className="w-4 h-4 fill-current" />
                    <span className="font-bold text-foreground">4.9/5</span>
                  </div>
                  <p className="text-muted-foreground">انضم إلى +25,000 طالب مبدع</p>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-12 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[ 
              { icon: PlayCircle, title: "المونتاج", desc: "Premiere & After Effects", color: "text-blue-500" },
              { icon: Palette, title: "التصميم", desc: "Photoshop & Illustrator", color: "text-pink-500" },
              { icon: Cpu, title: "الذكاء الاصطناعي", desc: "ChatGPT & Generative AI", color: "text-emerald-500" }
            ].map((cat, idx) => (
              <motion.div 
                key={idx} 
                whileHover={{ y: -5 }}
                className="p-6 rounded-2xl bg-card border border-border flex items-center gap-5"
              >
                <div className={`p-4 rounded-xl bg-background border border-border ${cat.color}`}>
                  <cat.icon className="w-8 h-8" />
                </div>
                <div>
                  <h3 className="text-xl font-bold">{cat.title}</h3>
                  <p className="text-muted-foreground text-sm">{cat.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Courses Section */}
      <section id="courses" className="py-24">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-end mb-12 gap-6">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold mb-4">أحدث الدورات التدريبية</h2>
              <p className="text-muted-foreground max-w-xl">
                اختر من بين مجموعة واسعة من الدورات التخصصية التي يقدمها أفضل المدربين، من المستوى المبتدئ إلى الاحتراف.
              </p>
            </div>
            <Button variant="link" asChild className="text-primary text-lg">
              <Link to={ROUTE_PATHS.COURSES} className="flex items-center gap-2">
                مشاهدة الكل
                <ArrowLeft className="w-5 h-5" />
              </Link>
            </Button>
          </div>

          <motion.div 
            variants={staggerContainer}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
          >
            {featuredCourses.map((course) => (
              <motion.div key={course.id} variants={staggerItem}>
                <CourseCard course={course} />
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-24 bg-secondary/50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">لماذا تختار منصتنا؟</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              نحن لا نقدم مجرد دروس فيديو، بل نبني بيئة تعليمية متكاملة تساعدك على تحقيق أهدافك.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[ 
              { icon: Zap, title: "تعلم عملي", desc: "مشاريع حقيقية تطبق عليها ما تعلمته مباشرة." },
              { icon: Users, title: "مجتمع تفاعلي", desc: "تواصل مع زملائك والمدربين في بيئة داعمة." },
              { icon: ShieldCheck, title: "شهادات معتمدة", desc: "احصل على شهادة عند إتمامك لأي دورة تدريبية." },
              { icon: Globe, title: "وصول مدى الحياة", desc: "ادفع مرة واحدة وشاهد المحتوى في أي وقت." }
            ].map((feature, idx) => (
              <motion.div 
                key={idx}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ delay: idx * 0.1 }}
                viewport={{ once: true }}
                className="p-8 rounded-2xl bg-background border border-border text-center hover:shadow-xl transition-shadow"
              >
                <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-6 text-primary">
                  <feature.icon className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-bold mb-3">{feature.title}</h3>
                <p className="text-muted-foreground">{feature.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section id="testimonials" className="py-24 overflow-hidden">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">ماذا يقول طلابنا</h2>
            <p className="text-muted-foreground">قصص نجاح من شباب عرب غيروا حياتهم المهنية معنا.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[ 
              { name: "محمد العلي", role: "مونتير حر", text: "الدورة غيرت نظرتي تماماً للمونتاج، أسلوب الشرح مبسط وعملي جداً.", avatar: "https://i.pravatar.cc/150?u=1" },
              { name: "ليلى أحمد", role: "مصممة جرافيك", text: "أفضل استثمار قمت به هذا العام. المحتوى غني جداً بالتفاصيل التي لا تجدها في اليوتيوب.", avatar: "https://i.pravatar.cc/150?u=2" },
              { name: "عمر خالد", role: "مطور محتوى", text: "دورة الذكاء الاصطناعي وفرت علي ساعات من العمل اليومي. شكراً للقائمين على الموقع.", avatar: "https://i.pravatar.cc/150?u=3" }
            ].map((testi, idx) => (
              <motion.div 
                key={idx}
                variants={fadeInUp}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true }}
                className="p-8 rounded-2xl bg-card border border-border relative"
              >
                <div className="absolute -top-4 -right-4 w-12 h-12 bg-primary rounded-full flex items-center justify-center text-primary-foreground italic font-serif text-2xl opacity-20">
                  &quot;
                </div>
                <p className="text-lg mb-8 relative z-10">{testi.text}</p>
                <div className="flex items-center gap-4">
                  <img src={testi.avatar} alt={testi.name} className="w-12 h-12 rounded-full object-cover" />
                  <div>
                    <h4 className="font-bold">{testi.name}</h4>
                    <p className="text-sm text-muted-foreground">{testi.role}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Latest Articles */}
      <section className="py-24 bg-muted/20">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-end mb-12 gap-6">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold mb-4">مقالات ونصائح تعليمية</h2>
              <p className="text-muted-foreground max-w-xl">
                ابقَ على اطلاع بأحدث التقنيات والنصائح في مجالات الإبداع الرقمي.
              </p>
            </div>
            <Button variant="outline" asChild className="rounded-xl">
              <Link to={ROUTE_PATHS.ARTICLES}>
                تصفح المدونة
              </Link>
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {recentArticles.map((article) => (
              <ArticleCard key={article.id} article={article} />
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24">
        <div className="container mx-auto px-4">
          <div className="relative rounded-[2rem] bg-primary overflow-hidden p-12 md:p-20 text-center text-primary-foreground">
            <div className="absolute inset-0 z-0">
              <img src={IMAGES.AI_TECHNOLOGY_1} alt="CTA bg" className="w-full h-full object-cover opacity-10 mix-blend-overlay" />
              <div className="absolute inset-0 bg-primary/60 backdrop-blur-[2px]" />
            </div>
            
            <div className="relative z-10 max-w-2xl mx-auto">
              <h2 className="text-4xl md:text-5xl font-bold mb-6">جاهز لتبدأ رحلتك الإبداعية؟</h2>
              <p className="text-xl opacity-90 mb-10">
                انضم لآلاف الطلاب اليوم وابدأ في تعلم مهارات القرن الواحد والعشرين. العروض الحالية تنتهي قريباً!
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button asChild size="lg" variant="secondary" className="h-14 px-10 text-lg rounded-xl font-bold">
                  <Link to={ROUTE_PATHS.REGISTER}>سجل الآن مجاناً</Link>
                </Button>
                <Button asChild size="lg" variant="outline" className="h-14 px-10 text-lg rounded-xl border-white/30 text-white hover:bg-white/10">
                  <Link to={ROUTE_PATHS.COURSES}>استكشف الدورات</Link>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
