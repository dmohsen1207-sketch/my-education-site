import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, SlidersHorizontal, X, BookOpen, Filter } from 'lucide-react';
import { courses } from '@/data/index';
import { CourseCard } from '@/components/Cards';
import { COURSE_CATEGORIES, COURSE_LEVELS, CourseCategory, CourseLevel } from '@/lib/index';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { springPresets, fadeInUp, staggerContainer, staggerItem } from '@/lib/motion';

const Courses = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<CourseCategory | 'all'>('all');
  const [selectedLevel, setSelectedLevel] = useState<CourseLevel | 'all'>('all');

  const filteredCourses = useMemo(() => {
    return courses.filter((course) => {
      const matchesSearch = course.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                            course.description.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = selectedCategory === 'all' || course.category === selectedCategory;
      const matchesLevel = selectedLevel === 'all' || course.level === selectedLevel;
      
      return matchesSearch && matchesCategory && matchesLevel;
    });
  }, [searchQuery, selectedCategory, selectedLevel]);

  const resetFilters = () => {
    setSearchQuery('');
    setSelectedCategory('all');
    setSelectedLevel('all');
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Header Section */}
      <section className="relative py-16 overflow-hidden">
        <div className="absolute inset-0 bg-primary/5 -skew-y-3 transform origin-top-left" />
        <div className="container mx-auto px-4 relative">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={springPresets.gentle}
            className="max-w-3xl"
          >
            <h1 className="text-4xl md:text-5xl font-bold mb-4 text-foreground">
              استكشف <span className="text-primary">دوراتنا</span> التعليمية
            </h1>
            <p className="text-muted-foreground text-lg leading-relaxed">
              تعلم أحدث المهارات في المونتاج، التصميم، والذكاء الاصطناعي مع نخبة من الخبراء في العالم العربي. ابدأ رحلتك التعليمية اليوم.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Filter Bar */}
      <section className="sticky top-0 z-40 bg-background/80 backdrop-blur-md border-b border-border mb-12">
        <div className="container mx-auto px-4 py-4">
          <div className="flex flex-col lg:flex-row gap-4 items-center justify-between">
            {/* Search Input */}
            <div className="relative w-full lg:max-w-md">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <Input
                placeholder="ابحث عن دورة..."
                className="pr-10 bg-muted/50 border-border focus:ring-primary"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>

            {/* Filters */}
            <div className="flex flex-wrap items-center gap-3 w-full lg:w-auto">
              <div className="flex items-center gap-2 text-sm text-muted-foreground hidden md:flex">
                <Filter className="w-4 h-4" />
                <span>تصفية حسب:</span>
              </div>

              {/* Category Select */}
              <Select 
                value={selectedCategory} 
                onValueChange={(value) => setSelectedCategory(value as CourseCategory | 'all')}
              >
                <SelectTrigger className="w-[140px] bg-muted/50">
                  <SelectValue placeholder="التصنيف" />
                </SelectTrigger>
                <SelectContent align="end">
                  <SelectItem value="all">جميع التصنيفات</SelectItem>
                  {Object.entries(COURSE_CATEGORIES).map(([key, label]) => (
                    <SelectItem key={key} value={key}>{label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>

              {/* Level Select */}
              <Select 
                value={selectedLevel} 
                onValueChange={(value) => setSelectedLevel(value as CourseLevel | 'all')}
              >
                <SelectTrigger className="w-[140px] bg-muted/50">
                  <SelectValue placeholder="المستوى" />
                </SelectTrigger>
                <SelectContent align="end">
                  <SelectItem value="all">جميع المستويات</SelectItem>
                  {Object.entries(COURSE_LEVELS).map(([key, label]) => (
                    <SelectItem key={key} value={key}>{label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>

              {(searchQuery || selectedCategory !== 'all' || selectedLevel !== 'all') && (
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={resetFilters}
                  className="text-destructive hover:bg-destructive/10 gap-2"
                >
                  <X className="w-4 h-4" />
                  مسح التصفية
                </Button>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Course Grid */}
      <section className="container mx-auto px-4">
        {filteredCourses.length > 0 ? (
          <motion.div 
            variants={staggerContainer}
            initial="hidden"
            animate="visible"
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
          >
            {filteredCourses.map((course) => (
              <motion.div key={course.id} variants={staggerItem}>
                <CourseCard course={course} />
              </motion.div>
            ))}
          </motion.div>
        ) : (
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="flex flex-col items-center justify-center py-24 text-center"
          >
            <div className="bg-muted/50 p-6 rounded-full mb-6">
              <BookOpen className="w-16 h-16 text-muted-foreground/40" />
            </div>
            <h3 className="text-2xl font-bold mb-2">لم نجد أي دورات تطابق بحثك</h3>
            <p className="text-muted-foreground mb-8 max-w-md">
              جرّب تغيير كلمات البحث أو استخدام تصنيفات مختلفة للعثور على ما تبحث عنه.
            </p>
            <Button onClick={resetFilters} variant="default" className="px-8">
              عرض جميع الدورات
            </Button>
          </motion.div>
        )}
      </section>

      {/* Quick Category Jump (Mobile Only) */}
      <div className="md:hidden fixed bottom-6 right-6 z-50">
        <Button 
          className="rounded-full w-14 h-14 shadow-xl shadow-primary/20"
          size="icon"
          onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
        >
          <SlidersHorizontal className="w-6 h-6" />
        </Button>
      </div>
    </div>
  );
};

export default Courses;