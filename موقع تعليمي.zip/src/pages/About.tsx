import React from 'react';
import { motion } from 'framer-motion';
import { 
  Target, 
  Users, 
  Cpu, 
  Video, 
  Palette, 
  CheckCircle2, 
  Trophy, 
  Star, 
  BookOpen 
} from 'lucide-react';
import { IMAGES } from '@/assets/images';
import { springPresets, fadeInUp, staggerContainer, staggerItem } from '@/lib/motion';

const stats = [
  { label: 'طلابنا المبدعون', value: '+15,000', icon: Users },
  { label: 'ساعات تعليمية', value: '+500', icon: BookOpen },
  { label: 'مدربين محترفين', value: '+20', icon: Star },
  { label: 'جوائز تميز', value: '12', icon: Trophy },
];

const values = [
  {
    title: 'التعلم التطبيقي',
    description: 'نركز على التطبيق العملي أكثر من النظري لضمان اكتساب المهارة الحقيقية.',
    icon: Video,
  },
  {
    title: 'الإبداع الرقمي',
    description: 'نواكب أحدث التقنيات في عالم التصميم والمونتاج لنبقيك دائماً في المقدمة.',
    icon: Palette,
  },
  {
    title: 'قوة الذكاء الاصطناعي',
    description: 'ندمج أدوات الذكاء الاصطناعي في سير العمل لتوفير الوقت وزيادة الإنتاجية.',
    icon: Cpu,
  },
];

export default function About() {
  return (
    <div className="min-h-screen pt-20 pb-16">
      {/* Hero Section */}
      <section className="relative py-24 overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src={IMAGES.STUDENT_LEARNING_6} 
            alt="Background" 
            className="w-full h-full object-cover opacity-20"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-background via-background/90 to-background" />
        </div>

        <div className="container mx-auto px-4 relative z-10 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={springPresets.gentle}
          >
            <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-primary to-purple-400 bg-clip-text text-transparent">
              نحن نصنع جيل المبدعين الرقميين
            </h1>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
              منصتنا تهدف لتمكين الشباب العربي من إتقان مهارات المستقبل في المونتاج، التصميم، والذكاء الاصطناعي بأحدث الأساليب العملية.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Story & Vision */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <motion.div 
              variants={fadeInUp}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              className="relative"
            >
              <div className="absolute -top-4 -right-4 w-24 h-24 bg-primary/20 rounded-full blur-3xl" />
              <img 
                src={IMAGES.STUDENT_LEARNING_6} 
                alt="Learning" 
                className="rounded-3xl shadow-2xl border border-border/50 relative z-10"
              />
              <div className="absolute -bottom-6 -left-6 bg-card p-6 rounded-2xl shadow-xl border border-border z-20">
                <div className="flex items-center gap-4">
                  <div className="p-3 bg-primary/10 rounded-full text-primary">
                    <Target className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="font-bold text-lg">رؤيتنا</p>
                    <p className="text-sm text-muted-foreground">الريادة في التعليم الرقمي</p>
                  </div>
                </div>
              </div>
            </motion.div>

            <motion.div
              variants={staggerContainer}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              className="space-y-8"
            >
              <motion.div variants={staggerItem}>
                <h2 className="text-3xl font-bold mb-4">رسالتنا التعليمية</h2>
                <p className="text-muted-foreground leading-relaxed text-lg">
                  نؤمن أن التعليم يجب أن يكون ممتعاً، متاحاً، ومرتبطاً بسوق العمل. بدأنا هذه المنصة لسد الفجوة بين المحتوى الأكاديمي والاحتياجات الفعلية للمصممين والمخرجين وصناع المحتوى.
                </p>
              </motion.div>

              <motion.div variants={staggerItem} className="space-y-4">
                <div className="flex items-start gap-4">
                  <CheckCircle2 className="w-6 h-6 text-primary mt-1 shrink-0" />
                  <p className="text-foreground font-medium">توفير محتوى تعليمي باللغة العربية بجودة عالمية.</p>
                </div>
                <div className="flex items-start gap-4">
                  <CheckCircle2 className="w-6 h-6 text-primary mt-1 shrink-0" />
                  <p className="text-foreground font-medium">بناء مجتمع تفاعلي للمبدعين يتبادلون فيه الخبرات.</p>
                </div>
                <div className="flex items-start gap-4">
                  <CheckCircle2 className="w-6 h-6 text-primary mt-1 shrink-0" />
                  <p className="text-foreground font-medium">مواكبة طفرة الذكاء الاصطناعي وتطويعها في المجالات الإبداعية.</p>
                </div>
              </motion.div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 bg-muted/30 border-y border-border">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="text-center space-y-2"
              >
                <div className="inline-flex p-3 bg-primary/5 rounded-2xl text-primary mb-2">
                  <stat.icon className="w-6 h-6" />
                </div>
                <div className="text-3xl font-bold">{stat.value}</div>
                <div className="text-sm text-muted-foreground">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Our Values Section */}
      <section className="py-24">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold mb-4">لماذا تختار منصتنا؟</h2>
            <p className="text-muted-foreground">نحن لا نقدم مجرد دورات، بل نصمم رحلة احترافية متكاملة</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {values.map((value, index) => (
              <motion.div
                key={index}
                variants={fadeInUp}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true }}
                transition={{ delay: index * 0.2 }}
                className="p-8 bg-card border border-border rounded-3xl hover:border-primary/50 transition-colors group"
              >
                <div className="w-14 h-14 bg-primary/10 rounded-2xl flex items-center justify-center text-primary mb-6 group-hover:scale-110 transition-transform">
                  <value.icon className="w-7 h-7" />
                </div>
                <h3 className="text-xl font-bold mb-3">{value.title}</h3>
                <p className="text-muted-foreground leading-relaxed">
                  {value.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Founder Section */}
      <section className="py-20 bg-gradient-to-b from-transparent to-primary/5">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto bg-card border border-border rounded-3xl p-8 md:p-12 overflow-hidden relative">
            <div className="absolute top-0 right-0 w-64 h-64 bg-primary/5 rounded-full blur-3xl -mr-32 -mt-32" />
            
            <div className="flex flex-col md:flex-row items-center gap-12 relative z-10">
              <div className="w-48 h-48 rounded-full overflow-hidden border-4 border-primary/20 shrink-0 shadow-2xl">
                <img 
                  src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=200&h=200&fit=crop" 
                  alt="Founder" 
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="text-center md:text-right space-y-4">
                <div className="inline-block px-3 py-1 bg-primary/10 text-primary text-xs font-bold rounded-full mb-2">
                  مؤسس المنصة
                </div>
                <h3 className="text-3xl font-bold">أحمد المبدع</h3>
                <p className="text-lg text-muted-foreground">
                  خبير في صناعة المحتوى المرئي وتطبيقات الذكاء الاصطناعي بخبرة تزيد عن 10 سنوات. هدفي هو تبسيط أعقد المهارات التقنية لتمكين الشباب العربي من دخول سوق العمل العالمي.
                </p>
                <div className="flex justify-center md:justify-start gap-4">
                  <div className="text-center">
                    <div className="font-bold">+50k</div>
                    <div className="text-xs text-muted-foreground">متابع</div>
                  </div>
                  <div className="w-px h-8 bg-border" />
                  <div className="text-center">
                    <div className="font-bold">+10</div>
                    <div className="text-xs text-muted-foreground">سنوات خبرة</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-20">
        <div className="container mx-auto px-4 text-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="max-w-2xl mx-auto space-y-8"
          >
            <h2 className="text-3xl md:text-4xl font-bold">هل أنت مستعد لبدء رحلتك الإبداعية؟</h2>
            <p className="text-muted-foreground text-lg">
              انضم إلينا اليوم وابدأ في تعلم المهارات التي ستغير مسارك المهني.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <button className="px-8 py-4 bg-primary text-primary-foreground rounded-full font-bold hover:scale-105 transition-transform shadow-lg shadow-primary/20">
                تصفح الدورات المتاحة
              </button>
              <button className="px-8 py-4 bg-secondary text-secondary-foreground rounded-full font-bold hover:bg-accent transition-colors">
                تواصل معنا
              </button>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
