export const ROUTE_PATHS = {
  HOME: "/",
  COURSES: "/courses",
  COURSE_DETAIL: "/courses/:id",
  ARTICLES: "/articles",
  ABOUT: "/about",
  CONTACT: "/contact",
  DASHBOARD: "/dashboard",
  LOGIN: "/login",
  REGISTER: "/register",
} as const;

export type CourseLevel = "beginner" | "intermediate" | "advanced";
export type CourseCategory = "editing" | "design" | "ai";

export const COURSE_LEVELS: Record<CourseLevel, string> = {
  beginner: "مبتدئ",
  intermediate: "متوسط",
  advanced: "متقدم",
};

export const COURSE_CATEGORIES: Record<CourseCategory, string> = {
  editing: "مونتاج",
  design: "تصميم",
  ai: "ذكاء اصطناعي",
};

export interface Lesson {
  id: string;
  title: string;
  duration: string;
  videoUrl: string;
  isFree: boolean;
  order: number;
}

export interface Course {
  id: string;
  title: string;
  description: string;
  longDescription?: string;
  category: CourseCategory;
  level: CourseLevel;
  price: number | "free";
  image: string;
  instructorId: string;
  lessons: Lesson[];
  duration: string;
  rating: number;
  studentsCount: number;
  requirements: string[];
  whatYouWillLearn: string[];
  tools: string[];
}

export interface User {
  id: string;
  name: string;
  email: string;
  avatar?: string;
  role: "student" | "admin";
  enrolledCourses: string[];
  completedLessons: string[];
  createdAt: string;
}

export interface Article {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  author: string;
  authorImage?: string;
  date: string;
  image: string;
  category: string;
  readTime: string;
  tags: string[];
}

export interface Instructor {
  id: string;
  name: string;
  role: string;
  bio: string;
  avatar: string;
  coursesCount: number;
  studentsCount: number;
  socialLinks?: {
    twitter?: string;
    linkedin?: string;
    youtube?: string;
  };
}

export interface ContactMessage {
  name: string;
  email: string;
  subject: string;
  message: string;
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
}